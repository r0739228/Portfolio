# 1ITF vervolg skillstaken 
Dit is de uitwerking van **skillstaak 2** en **skillstaak 3** door Simon Duchateau uit 1ITFE van de Thomas More Hogeschool (campus Geel)
<p align="center">
    <img src="https://www.thomasmore.be/themes/wundertheme/logo.svg" alt="Thomas More Kempen" width="300" />
</p>

